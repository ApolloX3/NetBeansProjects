
package pfcountdown;


public class PfCountDown {

    public static void main(String[] args) 
    {
    Title tim = new Title("Count Down", "Count down until blast off! ");  
    tim.printTitle();
    System.out.println("");
    
    Repeat pete = new Repeat();
    pete.goAgain();
    
            
    }
    
}
